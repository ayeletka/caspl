#include <stdio.h>
/*while(true):
	count number of neighbors,
	resume
	update the life of the cell.
*/


void run(int index,int index2, int index3) {
	while (1) {
		printf("Hello!  - %d -- %d \n\n", index, index2);


		/*resume:*/
		__asm__("xor 	%ebx, %ebx");
		__asm__("call 	resume");

	}
}

#include "util.h"


#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19

#define STDOUT 1
#define SEEK_SET 0
int main (int argc , char* argv[], char* envp[])
{
  if(argc!=3){
   system_call(SYS_WRITE,STDOUT,"Wrong parameters... Exiting!\n", 29);
   return 0;
  }
  char* fileName = argv[1];
  char* name = argv[2];
  system_call(SYS_WRITE,STDOUT, "Hello!\n",7);
  int pfile =  system_call(SYS_OPEN, fileName, 2,777); 
  system_call(SYS_LSEEK, pfile, 657, SEEK_SET);
   system_call(SYS_WRITE, pfile, "      ", 6);
     system_call(SYS_LSEEK, pfile, 657, SEEK_SET);
  system_call(SYS_WRITE, pfile, name, strlen(name));
    system_call(SYS_WRITE, pfile, ".", 1);

  system_call(SYS_CLOSE, pfile);
  system_call(SYS_WRITE,STDOUT, "Bye!\n",5);
  return 0;
}

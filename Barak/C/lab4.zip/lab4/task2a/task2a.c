#include "util.h"

#define BUF_SIZE 1024.
#define O_RDONLY 0

#define O_RDRW 2

#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_GETDENTS 141
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define DT_REG 8
#define SEEK_SET 0
#define O_CREATE 64



int filesOnly = 0;
char *suffix ;
int suffixOnly = 0;
typedef struct ent{
     int inode;
     int offset;
     short len;
     char buf[1];
     char pad;
     char type;
     
}ent;

extern int system_call();
void print(char* buf){
     system_call(SYS_WRITE, STDOUT, buf, strlen(buf));    
}
void printchar(char *buf){
     system_call(SYS_WRITE, STDOUT, buf, 1);    
}
void println(char* buf){
     print(buf);
     print("\n");
}
void printNum(int num){
     print(itoa(num));
}




int main (int argc , char* argv[], char* envp[]){
     int i = 0;
     for(i=1; i<argc; i++){
	if(strcmp(argv[i],"-s")==0){
	     suffix = argv[++i];
	     suffixOnly = 1;
	}
	else{
	     print("invalid parameters!");
	     return 1;
	}
     }
     char buf[8192];
     ent *entp = buf;
     int fd;
     int nread;
     char* buffer;
     fd = system_call(SYS_OPEN, "/home/barak/workspace/lab4/task2a/mydir", O_RDONLY, 0777);
     nread = system_call(SYS_GETDENTS, fd, buf, 2000);
     if(nread == -1)
	print("Error opening");
     printNum(nread);
     println("..");
     printNum(fd);
     print("\n");
     print("Suffix: ");
     printchar(suffix);
     println(" ");

     int read = 0;
     while(read < nread){
	int lastChar = (strlen(entp->buf)-1);
	print(entp->buf+lastChar);
	if(suffixOnly == 0||entp->type == 115 && strcmp(entp->buf+lastChar, suffix)==0){
	    
	     println("");
	print("Name: ");
	println(entp-> buf);
	print("Offset: ");
	printNum(entp->offset);
	println("");
	print("inode: ");
	printNum(entp->inode);
	println("");
	print("Length: ");
	printNum(entp->len);
	println(" ");
	
	print("Type: ");
	printNum(entp->type);
	println("");
	}
	read = read + entp->len;
	entp= (buf + read);
	
     }
     println("");
     printNum(sizeof(ent));
     system_call(SYS_CLOSE, fd);
     println("");
     println("Done...");
     return 0;
}




/*
 * 
 *      initialize();
 *     int i;
 *     for(i=1; i<argc; i++){
 *	if(strcmp(argv[i],"-i")==0){
 *	     inputFile = system_call(SYS_OPEN, argv[++i], 2 ,777);
 *	}
 *	else if(strcmp(argv[i],"-o")==0){
 *	     
 *	     outputFilesCount = (int)(*argv[++i] -48);
 *	     if(outputFilesCount<1 || outputFilesCount>5){
 *		print("Select a number between 1 to 5 please!");
 *		return 1;
 *	     }
 *	}
 *	else{
 *	     print("invalid parameters!");
 *	     return 1;
 *	}
 *     }
 *     initializeOutputFiles();
 *     char in;
 *     int bytesRead = system_call(SYS_READ, inputFile, &in, 1);
 *     if(bytesRead >0){
 *	print("\n");
 *	print(itoa(count++));
 *	print(":");
 *	writeBytes(in); 
 *     }
 *     while(bytesRead>0){
 *	bytesRead = system_call(SYS_READ, inputFile, &in, 1);
 *	writeBytes(in);
 *     }
 *     cleanup();
 * int openFile(char* filename){
 *     int pfile =  system_call(SYS_OPEN, filename, 66 ,777);
 *     return pfile;
 * }
 * 
 * void updateOutput(){
 *     if(outputFilesCount>0){
 *	fileIndex = (fileIndex + 1)%outputFilesCount;
 *	outputFile = (int)outputArray[fileIndex];
 *     }
 * }
 * 
 * void initialize(){
 *     inputFile = STDIN;
 *     outputFile = STDOUT;
 * }
 * 
 * void print(char* buf){
 *     system_call(SYS_WRITE, outputFile, buf, strlen(buf));    
 * }
 * void printNum(int num){
 *     print(itoa(num));
 * }
 * void initializeOutputFiles(){
 *     if(outputFilesCount==0)
 *	return;
 *     int i;
 *     for(i=0; i<outputFilesCount; i++){
 *	
 *	print("Enter output file ");
 *	printNum(i+1);
 *	print(":\n");
 *	char tmp[256];
 *	system_call(SYS_READ, STDIN, &tmp, 256);
 *	outputArray[i] = (int*)openFile(tmp);
 *     }
 *     outputFile = (int)outputArray[0];
 * }
 * 
 * void writeBytes(char in){
 *     print(&in);
 *     if(in == '*'||in == '@'){
 *	updateOutput();
 *	print("\n");
 *	print(itoa(count++));
 *	print(":");
 *     }
 * }
 * 
 * void cleanup(){
 *     if(inputFile!=STDIN){
 *	system_call(SYS_CLOSE, inputFile); 
 *     }
 *     if(outputFilesCount > 0){
 *	int i;
 *	for(i = 0; i<outputFilesCount; i++){
 *	     system_call(SYS_CLOSE, outputArray[i]);
 *	}
 *     }
 * }
 * 
 */

#include "util.h"


#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define SEEK_SET 0

void print(char* buf, int length){
  system_call(SYS_WRITE, STDOUT, buf, length);
  
}

int count = 1;
void writeBytes(char in){
    print(&in, 1);
  if(in == '*'||in == '@'){
    print("\n", 1);
    print(itoa(count++), strlen(itoa(count)));
    print(":", 1);
  }
}

int main (int argc , char* argv[], char* envp[]){
  int c = 3;
  char in;
  
  int bytesRead = system_call(SYS_READ, STDIN, &in, 1);
  if(bytesRead >0){
    print("\n", 1);
    print(itoa(count++), strlen(itoa(count)));
    print(":", 1);
   writeBytes(in); 
  }
  
  while(bytesRead>0){
    bytesRead = system_call(SYS_READ, STDIN, &in, 1);
      writeBytes(in);
  }
 // printf("\n%d:",count);
  count ++;
 // printf("%c", c); 
  while(c == 'w'){
    //    c = fgetc(stdin);
      switch(c){
        case('@'):
         // printf("%c", c); 
          //printf("\n%d:", count);
          count = count +1;
          break;
        case('*'):
          //printf("%c", c); 
          //printf("\n%d:", count);
          count = count +1;
          break;
        default:
          //printf("%c", c); 
          break;
  }
  
   
  }
  //printf("\n");
  return 0;
}
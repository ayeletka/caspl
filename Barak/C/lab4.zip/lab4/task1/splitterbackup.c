#include "util.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define SEEK_SET 0


int main (int argc , char* argv[], char* envp[]){
  
  int c;
  int count = 1;

  
  system_call(SYS_READ, STDIN, c, 1);
  printf("\n%d:",count);
  count ++;
  printf("%c", c); 
  while(c != EOF){
        c = fgetc(stdin);
      switch(c){
        case('@'):
          printf("%c", c); 
          printf("\n%d:", count);
          count = count +1;
          break;
        case('*'):
          printf("%c", c); 
          printf("\n%d:", count);
          count = count +1;
          break;
        default:
          printf("%c", c); 
          break;
  }
  
   
  }
  printf("\n");
  return 0;
}




/*
 * {
  if(argc!=3){
   system_call(SYS_WRITE,STDOUT,"Wrong parameters... Exiting!\n", 29);
   return 0;
  }
  char* fileName = argv[1];
  char* name = argv[2];
  system_call(SYS_WRITE,STDOUT, "Hello!\n",7);
  int pfile =  system_call(SYS_OPEN, fileName, 2,777); 
  system_call(SYS_LSEEK, pfile, 657, SEEK_SET);
   system_call(SYS_WRITE, pfile, "      ", 6);
     system_call(SYS_LSEEK, pfile, 657, SEEK_SET);
  system_call(SYS_WRITE, pfile, name, strlen(name));
    system_call(SYS_WRITE, pfile, ".", 1);

  system_call(SYS_CLOSE, pfile);
  system_call(SYS_WRITE,STDOUT, "Bye!\n",5);
  return 0;
}
*/
#include "util.h"

#define O_RDRW 2
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define SEEK_SET 0
#define O_CREATE 64

int inputFile;
int outputFile;
int* outputArray[5];
char* str;
int fileIndex = 0;
int outputFilesCount = 0;
int count = 1;
int openFile(char* filename){
     int pfile =  system_call(SYS_OPEN, filename, 66 ,777);
     return pfile;
}

void updateOutput(){
     if(outputFilesCount>0){
	fileIndex = (fileIndex + 1)%outputFilesCount;
	outputFile = (int)outputArray[fileIndex];
     }
}

void initialize(){
     inputFile = STDIN;
     outputFile = STDOUT;
}

void print(char* buf){
     system_call(SYS_WRITE, outputFile, buf, strlen(buf));    
}
void printNum(int num){
     print(itoa(num));
}
void initializeOutputFiles(){
     if(outputFilesCount==0)
	return;
     int i;
     for(i=0; i<outputFilesCount; i++){
	
	print("Enter output file ");
	printNum(i+1);
	print(":\n");
	char tmp[256];
	system_call(SYS_READ, STDIN, &tmp, 256);
	outputArray[i] = (int*)openFile(tmp);
     }
     outputFile = (int)outputArray[0];
}

void writeBytes(char in){
     print(&in);
     if(in == '*'||in == '@'){
	updateOutput();
	print("\n");
	print(itoa(count++));
	print(":");
     }
}

void cleanup(){
     if(inputFile!=STDIN){
	system_call(SYS_CLOSE, inputFile); 
     }
     if(outputFilesCount > 0){
	int i;
	for(i = 0; i<outputFilesCount; i++){
	     system_call(SYS_CLOSE, outputArray[i]);
	}
     }
}
int main (int argc , char* argv[], char* envp[]){
     initialize();
     int i;
     for(i=1; i<argc; i++){
	if(strcmp(argv[i],"-i")==0){
	     inputFile = system_call(SYS_OPEN, argv[++i], 2 ,777);
	}
	else if(strcmp(argv[i],"-o")==0){
	     
	     outputFilesCount = (int)(*argv[++i] -48);
	     if(outputFilesCount<1 || outputFilesCount>5){
		print("Select a number between 1 to 5 please!");
		return 1;
	     }
	}
	else{
	     print("invalid parameters!");
	     return 1;
	}
     }
     initializeOutputFiles();
     char in;
     int bytesRead = system_call(SYS_READ, inputFile, &in, 1);
     if(bytesRead >0){
	print("\n");
	print(itoa(count++));
	print(":");
	writeBytes(in); 
     }
     while(bytesRead>0){
	bytesRead = system_call(SYS_READ, inputFile, &in, 1);
	writeBytes(in);
     }
     cleanup();
     return 0;
}

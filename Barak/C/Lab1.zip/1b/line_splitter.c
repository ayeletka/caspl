
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
  int c;
  int count = 1;

  
  c = fgetc(stdin);
  printf("\n%d:",count);
  count ++;
  printf("%c", c); 
  while(c != EOF){
	c = fgetc(stdin);
      switch(c){
	case('@'):
	  printf("%c", c); 
	  printf("\n%d:", count);
	  count = count +1;
	  break;
	case('*'):
	  printf("%c", c); 
	  printf("\n%d:", count);
	  count = count +1;
	  break;
	default:
	  printf("%c", c); 
	  break;
  }
  
   
  }
  printf("\n");
  return 0;
}

   

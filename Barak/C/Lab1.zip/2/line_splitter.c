
#include <stdio.h>
#include <string.h>

FILE* output[5];
  char* str;
  int digit = 0;
  int specialChar = 0;
  int file = 0;
  FILE * input;
  int outputFiles = 0;
  FILE * outputFile;
  char special = 'S';
  int c;
  int count = 1;
  int i;
  int fileIndex = 0;
  
void updateOutput(){
  fileIndex = (fileIndex + 1)%outputFiles;
  outputFile = output[fileIndex];
}
 
int main(int argc, char **argv) {
   
   outputFile = stdout;
  input = stdin;
  for(i=1; i<argc; i++){
    if(strcmp(argv[i],"-s")==0){
	specialChar = 1;
	special = *argv[++i];
    }
    else if(strcmp(argv[i],"-d")==0)
	digit = 1;
    else if(strcmp(argv[i],"-i")==0){
	file = 1;
        input = fopen(argv[++i], "r");
    }
       else if(strcmp(argv[i],"-o")==0){
	 fflush(stdout);
	file = 1;
	outputFiles = atoi(argv[++i]);
    }
    else{
	printf("invalid parameter - %s\n",argv[i]);
	return 1;
    }
  }
  
  for(i=0; i<outputFiles; i++){
    printf("Enter output file %d:\n", i+1);
      char tmp[256];
     gets(tmp);
    output[i] = fopen(tmp, "w+");
   }
  if(outputFiles!=0){
      outputFile = output[0];
  }
  c = fgetc(input);
  fprintf(outputFile, "\n%d:",count);
 
  count ++;
  fprintf(outputFile, "%c", c); 

  while(c != EOF){
	c = fgetc(input);
      switch(c){
	case('@'):
	  fprintf(outputFile, "%c", c); 
	  updateOutput();
	  fprintf(outputFile, "\n%d:", count);
	  count = count +1;
	  
	  break;
	case('*'):
	  fprintf(outputFile, "%c", c); 
	  	  updateOutput();

	  fprintf(outputFile, "\n%d:", count);
	  count = count +1;
	  break;
	default:
	  fprintf(outputFile, "%c", c); 
	  break;
  }
    if(specialChar == 1 && c == special){
      	  updateOutput();
	fprintf(outputFile, "\n%d:", count);
	count ++;

    }
      if(digit == 1 && c <= '9' && c>= '0'){
	updateOutput();
	fprintf(outputFile, "\n%d:", count);
	count ++;
    }
  }
  fprintf(outputFile, "\n");
  return 0;
}

   

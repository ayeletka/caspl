
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
  int digit = 0;
  int specialChar = 0;
  char special = 'S';
  int c;
  int count = 1;
  int i;
  for(i=1; i<argc; i++){
    if(strcmp(argv[i],"-s")==0){
	specialChar = 1;
	special = *argv[++i];
    }
    else if(strcmp(argv[i],"-d")==0)
	digit = 1;
    else{
	printf("invalid parameter - %s\n",argv[i]);
	return 1;
    }
  }
  
  c = fgetc(stdin);
  printf("\n%d:",count);
  count ++;
  printf("%c", c); 
  while(c != EOF){
	c = fgetc(stdin);
      switch(c){
	case('@'):
	  printf("%c", c); 
	  printf("\n%d:", count);
	  count = count +1;
	  break;
	case('*'):
	  printf("%c", c); 
	  printf("\n%d:", count);
	  count = count +1;
	  break;
	default:
	  printf("%c", c); 
	  break;
  }
  if(specialChar == 1 && c == special){
      printf("\n%d:", count);
      count ++;
  }
    if(digit == 1 && c <= '9' && c>= '0'){
      printf("\n%d:", count);
      count ++;
  }
  }
  printf("\n");
  return 0;
}

   

#include <stdio.h>
 
char censor(char c) {
  if(c == '!') {
    return '.';
  }
  return c;
}
/* Gets a character c, and returns it in lower case. 
 Characters that do not have a lower case, are returned unchanged */
char to_lower(char c){ 

  if(c<'Z' && c>'A'){
    c = c + 32;
  }
  return c;
}

char cprt(char c) /* Prints the value of c, followed by a new line, and returns c unchanged */
{
  printf("%c\n", c); 
  return c;
}
char quit(char c){
  exit(0);
  return 'c';
}
char my_get(char c) /* Ignores c, reads and returns a character from stdin using fgetc. 
                 Returns 0 when a new line character is read. */
{
  char input = fgetc(stdin);
  if(input == '\n')
    return 0;
  return input;
}

void for_each(char *array, char (*f) (char)){
    while(*array != '\0'){
      *array = f(*array);
      array = array + 1;
    }
}
 
 
int main(int argc, char **argv){
char c[5];
for_each(c, my_get);
for_each(c, cprt);
for_each(c, to_lower);
for_each(c, censor);
for_each(c, quit); 

  return 0;
}
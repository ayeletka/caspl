/* $Id: count-words.c 858 2010-02-21 10:26:22Z tolpin $ */

#include <stdio.h>
#include <string.h>

/* return string "word" if the count is 1 or "words" otherwise */

/* print the number of words in the command line and return the number as the exit code */
int main(int argc, char **argv) {
  /* part 1C:
  int iarray[3];
  char carray[3];
  int i;
    printf("%p\n", &iarray);
    printf("%p\n", &iarray+1);
    printf("%p\n", &carray);
    printf("%p\n", &carray+1);
  }
  */
  
  /*
   int iarray[] = {1,2,3};
  char carray[] = {'a','b','c'};
  int* iarrayPtr;
  char* carrayPtr;
  iarrayPtr = iarray;
  carrayPtr = carray;
  printf("%d\n", *iarrayPtr);
  printf("%d\n", *iarrayPtr + 1);
  printf("%d\n", *iarrayPtr + 2);
  printf("%c\n", *carrayPtr);
  printf("%c\n", *carrayPtr +1);
  printf("%c\n", *carrayPtr+ 2);
  int* ptr;
  printf("%d\n", ptr);
  */
  
  
  
  return 0;
}

   

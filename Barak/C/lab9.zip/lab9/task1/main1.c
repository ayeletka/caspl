#include <stdio.h>

#define	BUFFER_SIZE	(128)

extern int my_func();

int main(int argc, char** argv)
{
	
  printf("Hello\n");
 
  my_func();

  return 0;
}

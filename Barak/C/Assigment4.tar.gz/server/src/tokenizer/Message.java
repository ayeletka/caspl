package tokenizer;

public interface Message<T> {
	
	public void addHeader(String headerName, String headerValue);
}
